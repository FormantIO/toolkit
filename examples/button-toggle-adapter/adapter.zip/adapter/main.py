
from adapter import Adapter

def main():
    adapter = Adapter()
    adapter.start()

if __name__ == "__main__":
    main()