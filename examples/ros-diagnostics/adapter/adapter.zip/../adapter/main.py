from ros_diagnostics_collector import RosDiagnosticsCollector

if __name__ == "__main__":
    RosDiagnosticsCollector()
