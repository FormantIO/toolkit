#! /bin/bash

zip -r adapter.zip ../adapter 